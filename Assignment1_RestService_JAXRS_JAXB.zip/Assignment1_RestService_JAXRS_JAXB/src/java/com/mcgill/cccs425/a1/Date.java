/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mcgill.cccs425.a1;

import java.time.LocalDate;

/**
 *
 * @author pkieu
 */
 public class Date{
        private int day;
        private int month;
        private int year;
        
        public Date(){}
        public Date(int day, int month, int year){
//            this.day = day;
//            this.month = month;
//            this.year = year;
            int [] myDays = {31,29,31,30,31,31,30,31,30,31,30,31};
            
            if(month>=1 && month <=12)
                this.month = month;
            else Integer.valueOf(null);

            if(day>=1 && day <=myDays[month-1])
                this.day = day;
            else throw new IndexOutOfBoundsException();


            if(year>0 && year <= LocalDate.now().getYear())
                this.year = year;
            else throw new IndexOutOfBoundsException();
        }
        public int getDay() {
            return day;
        }
        public void setDay(int day) {
            
            this.day = day;
        }

        public int getMonth() {
            return month;
        }

        public void setMonth(int month) {
            this.month = month;
        }

        public int getYear() {
            return year;
        }

        public void setYear(int year) {
            this.year = year;
        }

        @Override
        public String toString() {
            return "Date{" +
                "day=" + day +
                ", month=" + month +
                ", year=" + year +
                '}';
        }       
    }