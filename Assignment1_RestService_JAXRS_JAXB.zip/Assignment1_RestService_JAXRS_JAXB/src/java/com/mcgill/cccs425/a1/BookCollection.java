/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mcgill.cccs425.a1;

import java.util.concurrent.CopyOnWriteArrayList;

/**
 *
 * @author pkieu
 */
public class BookCollection {
    private static CopyOnWriteArrayList<Book> books = new CopyOnWriteArrayList<>();;
    
    
    public BookCollection(){
       
    }

    public CopyOnWriteArrayList<Book> getAllBooks(){
        return books;
    }

    public Book getBookById(int id){
        for(Book book : books){
            if(book.getId() == id){
                return book;
            }
        }
        return null;
    }

    public Book getBookByTitle(String title){
        for(Book book : books){
            if(book.getTitle().equals(title)){
                return book;
            }
        }
        return null;
    }

    public void create(Book book){
        int id=0;
        if(books.size()==0) 
            id = 1;
        else
           id= books.get(books.size()-1).getId()+1;
        book.setId(id);
        books.add(book);
    }

    public void delete(int id){
         for(Book book : books){
            if(book.getId() == id){
                books.remove(book);
                break;
            }
        }
    }


    public void deleteAll(){
        books.clear();
       
    }

    public void update(Book book, int id){
        for(Book b : books){
            if(b.getId() == id){
                b.setTitle(book.getTitle());
                b.setDate(book.getDate());
            }
        }
    }
}
