/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mcgill.cccs425.soap;

import javax.xml.ws.WebFault;

@WebFault(name="MySOAPFault", targetNamespace="http://soap.cccs425.mcgill.com/")
public class MySOAPFault extends Exception {
    public MySOAPFault(String message) {
        super(message);
    }

    public MySOAPFault(String message, Throwable cause) {
        super(message, cause);
    }

}
