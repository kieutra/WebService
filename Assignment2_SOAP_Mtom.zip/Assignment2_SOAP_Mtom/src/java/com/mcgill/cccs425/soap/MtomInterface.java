/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package com.mcgill.cccs425.soap;

import javax.activation.DataHandler;
import javax.jws.WebMethod;
import javax.jws.WebService;
import javax.xml.ws.BindingType;
import javax.xml.ws.soap.SOAPBinding;


@WebService
@BindingType(value = SOAPBinding.SOAP11HTTP_MTOM_BINDING)

public interface MtomInterface {   
    @WebMethod
    String upload(DataHandler file);
    
    @WebMethod
    DataHandler download()throws MySOAPFault;
    
    @WebMethod
    public int [] fibonacci(int n); 
}
