/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/WebServices/WebService.java to edit this template
 */
package com.mcgill.cccs425.soap;

import java.io.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.activation.DataHandler;
import javax.jws.*;
import javax.xml.ws.soap.MTOM;


@MTOM(enabled=true, threshold=1024)
@WebService(endpointInterface="com.mcgill.cccs425.soap.MtomInterface")

public class MtomService implements MtomInterface{

// private ByteArrayOutputStream baos;
// private String mimeType;
    private DataHandler file;


    @Override
    public String upload(@WebParam(name = "file") DataHandler file) {
        this.file = file;
//        mimeType = file.getContentType();
//        baos = new ByteArrayOutputStream();
//
//        try{
//         file.writeTo(baos);
//        }catch (IOException ex) {
//         ex.getMessage();
//        }
//
//         try {
//             baos.close();
//         } catch (IOException ex) {
//             Logger.getLogger(MtomService.class.getName()).log(Level.SEVERE, null, ex);
//         }
//         
//         if(baos.size() < 13)
//             return "no attached file";        
        return "upload succeeded";
    }
    
    
    @Override
    public DataHandler download() throws MySOAPFault {
//        if(baos.size() < 13){
//            Throwable t = new IllegalArgumentException("Empty File");
//            throw new MySOAPFault("There is no file found", t);
//
//        } else{
//         return new DataHandler(baos.toByteArray(), mimeType);
//    }
    return file;
}

    @Override
    public int[] fibonacci(@WebParam(name = "n")int n) {
        int arr[] = new int[n];
        arr[0] = 0;
        arr[1] = 1;
        for(int i = 2; i<n; i++)
             arr[i] = arr[i-1] + arr[i-2];
       return arr;
    }    
}
