package com.mcgill.cccs425.a3.TotalPriceClient.model;

import java.io.Serializable;

/**
 * <h1>FruitPrice</h1>
 * @author Thi Thanh Tra Kieu — McGill University ID 261 066 512
 * @author Elizaveta Starostina — McGill University ID 261 067 603
 * @author Francois Boulay-Handfield — McGill University ID 261 065 127
 */

public class Fruit implements Serializable{

    // ———————— Global Variables ————————

    private int id;
    private String fruitName;
    private String monthName;
    private double price;
    private int quantity;
    private double totalPrice;
    private String environment;


    public Fruit() {}


    public Fruit(int id, String fruit, String monthName, double price, int quantity, double totalPrice, String environment) {
        this.fruitName = fruit;
        this.monthName = monthName;
        this.price = price;
        this.quantity = quantity;
        this.totalPrice = totalPrice;
        this.environment = environment;
        this.id = id;

    }
    public Fruit(int id, String fruit, String monthName, double price, String environment) {

        this.environment = environment;
        this.fruitName = fruit;
        this.monthName = monthName;
        this.price = price;
        this.id = id;

    }

    // ———————— Public Getters and Setters follow Bean class principles ————————
    public void setId(int id){
        this.id = id;
    }
    public int getId() {
        return id;
    }

    public String getFruitName() {
        return fruitName;
    }
    public void setFruitName(String fruit) {
        this.fruitName = fruit;
    }
    public double getTotalPrice() {
        return totalPrice;
    }

    public void setTotalPrice(double totalPrice) {
        this.totalPrice = totalPrice;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public String getMonthName() {
        return monthName;
    }
    public void setMonth(String monthName) {
        this.monthName = monthName;

    }

    public double getPrice() {
        return price;
    }
    public void setPrice(double price) {
        if (price > 0) {
            this.price = price;
        }
    }


    public String getEnvironment() {
        return environment;
    }
    public void setEnvironment(String environment) {
        if (environment != null && !environment.isEmpty()) {
            this.environment = environment;
        }
    }

    @Override
    public String toString(){
        return "Fruit{" +
                "name='" + fruitName  +
                ", id=" + id +
                ", price=" + price +
                ", quantity=" + quantity +
                ", totalPrice=" + totalPrice +
                ", environment=" + environment +
                "}";

    }

}