package com.mcgill.cccs425.a3.TotalPriceClient.controller;


import com.mcgill.cccs425.a3.TotalPriceClient.model.Fruit;
import com.netflix.appinfo.InstanceInfo;
import com.netflix.discovery.EurekaClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import java.text.DecimalFormat;

@RestController
@RequestMapping("/fruit-total-price")
public class FruitTotalPriceController {
    @Autowired
    private EurekaClient eurekaClient;
    public FruitTotalPriceController(){}

//localhost:8100/fruit-total-price/fruit/Cherry/month/Feb/quantity/30
    @GetMapping("/fruit/{fruitName}/month/{monthName}/quantity/{quantityNo}")
    public Fruit getFruit(@PathVariable String fruitName, @PathVariable String monthName, @PathVariable int quantityNo){

        InstanceInfo service = eurekaClient.getApplication("month-price-service").getInstances().get(0);
        String hostname = service.getHostName();
        int port = service.getPort();

        RestTemplate rt = new RestTemplate();
        String resourceUrl = "http://"+hostname+":"+port+"/fruit-month-price/fruit/"+fruitName+"/month/"+monthName;
        Fruit aFruit = rt.getForObject(resourceUrl, Fruit.class);
        double totalPrice = Double.parseDouble(new DecimalFormat("#.00").format(aFruit.getPrice()*quantityNo));
        return new Fruit(aFruit.getId(), aFruit.getFruitName(), aFruit.getMonthName(), aFruit.getPrice(), quantityNo, totalPrice, aFruit.getEnvironment());
    }

}
