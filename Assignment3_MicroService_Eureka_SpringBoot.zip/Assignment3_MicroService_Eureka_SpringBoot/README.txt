Run those files in order:
1. ServerApplication.java in module Server
2. MonthPriceClientApplication in module MonthPrice_Client
3. TotalPriceEurekaClientApplication in module TotalPrice_EurekaClient