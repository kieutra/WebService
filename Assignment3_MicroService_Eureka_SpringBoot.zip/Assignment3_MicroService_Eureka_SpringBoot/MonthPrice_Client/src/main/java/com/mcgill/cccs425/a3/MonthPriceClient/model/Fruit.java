package com.mcgill.cccs425.a3.MonthPriceClient.model;

import java.io.Serializable;

public class Fruit implements Serializable {
    private int id;
    static private int count=10001;
    private String fruitName;
    private String monthName;
    private String price;
    private String environment;

    public Fruit(){}

    public Fruit(String fruitName, String monthName, String price, String environment) {
        this.id = count++;
        this.fruitName = fruitName;
        this.monthName = monthName;
        this.price = price;
        this.environment = environment;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getFruitName() {
        return fruitName;
    }

    public void setFruitName(String fruitName) {
        this.fruitName = fruitName;
    }

    public String getMonthName() {
        return monthName;
    }

    public void setMonthName(String monthName) {
        this.monthName = monthName;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public String getEnvironment() {
        return environment;
    }

    public void setEnvironment(String environment) {
        this.environment = environment;
    }
    public String toString(){
        return "Fruit{" +
                "id=" + id +
                ", fruitName='" + fruitName +
                ", price=" + price +
                ", environment=" + environment +
                "}";

    }
}
