package com.mcgill.cccs425.a3.MonthPriceClient.Controller;


import com.mcgill.cccs425.a3.MonthPriceClient.model.Fruit;
import com.mcgill.cccs425.a3.MonthPriceClient.repository.FruitMonthPrice;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/fruit-month-price")

//localhost:8000/fruit-month-price/fruit/Apricot/month/Jul
public class FruitMonthPriceController {
    @Value("${server.port}")
    private int serverPort;
    private final FruitMonthPrice repository = FruitMonthPrice.getInstance();
    public FruitMonthPriceController(){}

    @GetMapping("/fruit/{fruitName}/month/{monthName}")
    public ResponseEntity<Fruit> getFruitJson(@PathVariable String fruitName, @PathVariable String monthName){
        String environment = serverPort+"";
        Fruit aFruit = repository.getFruit(fruitName, monthName, environment);
        if(aFruit==null) return ResponseEntity.notFound().build();
        else return ResponseEntity.ok(aFruit);
    }
}
