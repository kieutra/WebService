package com.mcgill.cccs425.a3.MonthPriceClient.repository;

import com.mcgill.cccs425.a3.MonthPriceClient.model.Fruit;
import org.springframework.stereotype.Repository;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;

@Repository
public class FruitMonthPrice {
    private static FruitMonthPrice fmp;
    private final String FILE_NAME = "myData.csv";
    private List<String> months;
    private ConcurrentHashMap<String, List<String>> myFruitList;

    private FruitMonthPrice(){
        months = new CopyOnWriteArrayList<>();
        myFruitList = new ConcurrentHashMap<>();

    }
    public static FruitMonthPrice getInstance(){
        if(fmp==null)
            return new FruitMonthPrice();
        return fmp;
    }

    public Fruit getFruit(String fruit, String month, String environment){
        loadData();
        Fruit aFruit;
        if(myFruitList.containsKey(fruit)){
            for(int i = 0; i<months.size(); i++){
                if(months.get(i).equalsIgnoreCase(month)){
                    String fmp= myFruitList.get(fruit).get(i);
                    aFruit = new Fruit(fruit, month, fmp, environment);
                    return aFruit;
                }
            }
        }
        return null;
    }

    //load data from myData.csv
    public void loadData(){
        List<List<String>> records = new CopyOnWriteArrayList<>();
        List<String> fakeMonths = new CopyOnWriteArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader(FILE_NAME))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] values = line.split(",");
                records.add(Arrays.asList(values));
            }
        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        //get months from the data
        fakeMonths=records.get(0);
        for(int i = 1; i<fakeMonths.size(); i++){
            months.add(fakeMonths.get(i));
        }
        //remove the first line of data about months
        records.remove(0);
        //get map: String fruitNames & list prices
        List<String> fakePrices;
        for (int j = 0; j < records.size(); j++) {
            fakePrices = new CopyOnWriteArrayList<>();
            for (int i = 1; i < records.get(j).size(); i++) {
                fakePrices.add(records.get(j).get(i));
            }
            myFruitList.put(records.get(j).get(0), fakePrices);
        }
    }

}
