package com.mcgill.cccs425.a3.MonthPriceClient;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MonthPriceClientApplicationTests {

    @Test
    void contextLoads() {
    }

}
