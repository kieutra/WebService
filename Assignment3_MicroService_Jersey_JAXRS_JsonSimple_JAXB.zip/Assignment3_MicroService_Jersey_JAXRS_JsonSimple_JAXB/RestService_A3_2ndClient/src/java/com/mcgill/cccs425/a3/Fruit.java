/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mcgill.cccs425.a3;

import java.io.Serializable;


/**
 *
 * @author pkieu
 */

public class Fruit implements Serializable {
    private long id;
    private String title;
    private String price;
    private String monthName;
    private String environment;
    private String totalPrice;
    private int quantity;
    public Fruit(){}
    
//    public Fruit(String title, String monthName, String price,  String environment){
//        id = count++;
//        this.title = title;
//        this.price = price;
//        this.monthName = monthName;
//        this.environment = environment;
//    }
  public Fruit(long id, String title, String monthName, String price,int quantity, String totalPrice,  String environment){
       this.id = id;
        this.title = title;
        this.price = price;
        this.quantity = quantity;
        this.totalPrice = totalPrice;
        this.monthName = monthName;
        this.environment = environment;
    }
    
    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }
        public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }
    
    public void setTotalPrice(String totalPrice){
        this.totalPrice = totalPrice;
    }
    public String getTotalPrice(){
        return totalPrice;
    }
    
    public String getTitle() {   
        return title;
    }
    
    public void setPrice(String price){
        this.price = price;
    }
    public String getPrice() {   
        return price;
    }
    
    public void setTitle(String title){
        this.title = title;
    }
    public String getMonth() {   
        return monthName;
    }
    
    public void setMonth(String monthName){
        this.monthName = monthName;
    }

      public String getEnvironment() {
        return environment;
    }

    public void setEnvironment(String environment) {
        this.environment = environment;
    }
    @Override
    public String toString() {
        return "{\"id\"=" + id + ", \"title\"=" + title + ", \"price\"=" + price + ", \"month\"=" + monthName +", \"quantity\"=" + quantity +", \"totalPrice\"=" + totalPrice + ", \"environment\"=" + environment + "}";
    }
    
}
