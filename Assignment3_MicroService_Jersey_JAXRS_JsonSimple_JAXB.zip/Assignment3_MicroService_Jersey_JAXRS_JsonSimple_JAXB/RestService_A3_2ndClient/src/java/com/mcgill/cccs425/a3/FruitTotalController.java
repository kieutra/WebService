/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/WebServices/GenericResource.java to edit this template
 */
package com.mcgill.cccs425.a3;



import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.net.URL;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;
import javax.servlet.ServletContext;
import javax.ws.rs.Produces;
import javax.ws.rs.GET;

import javax.ws.rs.Path;

import javax.ws.rs.PathParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.io.*;
import java.net.*;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;



/**
 * REST Web Service
 *
 * @author pkieu
 */
@Path("/fruit")
public class FruitTotalController {
    
     @Context
    ServletContext scontext;
    private List<String> months;
    private ConcurrentHashMap<String, List<String>> myFruitList;

    public FruitTotalController() {
 
    }

    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public String getDouble(){
        double s = 8.5;
        
        return s+"";
    }

    
    @GET
    @Path("/{fruitName}/month/{monthName}/quantity/{quantity}")
    @Produces(MediaType.APPLICATION_JSON)
    public Fruit getFruit(@PathParam("fruitName") String fruit, @PathParam("monthName") String monthName, @PathParam("quantity") int quantity) throws MalformedURLException, IOException, ParseException {
        String path = "http://localhost:8080/RestService/price-month/fruit/"+ fruit + "/month/" + monthName;
    
        URL url = new URL(path);
       HttpURLConnection con = (HttpURLConnection) url.openConnection();
	con.setRequestMethod("GET"); // optional default is GET
	//add request header
	con.setRequestProperty("User-Agent", "Mozilla/5.0");
        String inline = ""; //{"environment":"8080","id":10007,"month":"Jan","price":"8.37","title":"Banana"}
	int responseCode = con.getResponseCode();
	if(responseCode != 200)
            throw new RuntimeException("HttpResponseCode: " +responseCode);
            else
            {
                Scanner sc = new Scanner(url.openStream());
                while(sc.hasNext())
                {
                inline+=sc.nextLine();
                }
                sc.close();
            }
    JSONParser parse = new JSONParser();
    JSONObject obj = (JSONObject)parse.parse(inline);
    long id = (long) obj.get("id");
    String fruitTotal = (String)obj.get("title");
    String monthTotal = (String)obj.get("month");
    String environment = (String) obj.get("environment");
    String priceTotal  =  (String) obj.get("price");
    double totalPrice = Double.parseDouble(priceTotal)*quantity;
    String priceFormat = String.format("%.2f", totalPrice);
    

   
  //  Fruit aFruit =  new Fruit(id, fruitTotal, monthTotal, priceTotal, quantity, totalPrice+"", environment ) ;

        return new Fruit(id, fruit, monthName, priceTotal, quantity, priceFormat, environment);
    }
       
    

}
