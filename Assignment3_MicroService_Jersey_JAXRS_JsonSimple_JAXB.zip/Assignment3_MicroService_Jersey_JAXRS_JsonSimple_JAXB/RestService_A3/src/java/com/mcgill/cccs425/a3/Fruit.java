/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mcgill.cccs425.a3;

import java.io.Serializable;


/**
 *
 * @author pkieu
 */

public class Fruit implements Serializable {
    private int id;
    private static int count = 10001;
    private String title;
    private String price;
    private String monthName;
    private String environment;
    public Fruit(){}
    
    public Fruit(String title, String monthName, String price,  String environment){
        id = count++;
        this.title = title;
        this.price = price;
        this.monthName = monthName;
        this.environment = environment;
    }
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
    
    public String getTitle() {   
        return title;
    }
    
    public void setPrice(String price){
        this.price = price;
    }
    public String getPrice() {   
        return price;
    }
    
    public void setTitle(String title){
        this.title = title;
    }
    public String getMonth() {   
        return monthName;
    }
    
    public void setMonth(String monthName){
        this.monthName = monthName;
    }

      public String getEnvironment() {
        return environment;
    }

    public void setEnvironment(String environment) {
        this.environment = environment;
    }
    @Override
    public String toString() {
        return "{\"id\"=" + id + ", \"title\"=" + title + ", \"price\"=" + price + ", \"month\"=" + monthName + ", \"environment\"=" + environment + "}";
    }
    
}
