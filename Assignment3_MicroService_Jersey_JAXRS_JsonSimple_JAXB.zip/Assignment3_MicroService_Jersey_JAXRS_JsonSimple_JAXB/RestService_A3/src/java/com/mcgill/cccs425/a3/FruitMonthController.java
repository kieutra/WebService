/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/WebServices/GenericResource.java to edit this template
 */
package com.mcgill.cccs425.a3;



import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;
import javax.servlet.ServletContext;
import javax.ws.rs.Produces;
import javax.ws.rs.GET;

import javax.ws.rs.Path;

import javax.ws.rs.PathParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

/**
 * REST Web Service
 *
 * @author pkieu
 */
@Path("/fruit")
public class FruitMonthController {
    
     @Context
    ServletContext scontext;
    private List<String> months;
    private ConcurrentHashMap<String, List<String>> myFruitList;

    public FruitMonthController() {
 
    }

    @GET
    @Path("/{fruitName}/month/{monthName}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getFruit(@PathParam("fruitName") String fruit, @PathParam("monthName") String monthName) {
        String environment = 8080+"";
        Fruit aFruit = getFruit(fruit, monthName, environment);
        if(aFruit == null)
            return Response.status(Response.Status.NOT_FOUND).build();
      return Response.ok(aFruit).build();
    }
    
    
    
    
    
    
      public Fruit getFruit(String fruit, String month, String environment){
        loadData();
        Fruit aFruit;
        if(myFruitList.containsKey(fruit)){
            for(int i = 0; i<months.size(); i++){
                if(months.get(i).equalsIgnoreCase(month)){
                    String fmp= myFruitList.get(fruit).get(i);
                    aFruit = new Fruit(fruit, month, fmp, environment);
                    return aFruit;
                }
            }
        }
        return null;
    }

    //load data from myData.csv
    public void loadData(){
        months = new CopyOnWriteArrayList<>();
        myFruitList = new ConcurrentHashMap<>();
        String fileName = scontext.getRealPath("/WEB-INF/classes/api/myData.csv");
        List<List<String>> records = new CopyOnWriteArrayList<>();
        List<String> fakeMonths = new CopyOnWriteArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader(fileName))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] values = line.split(",");
                records.add(Arrays.asList(values));
            }
        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        //get months from the data
        fakeMonths =records.get(0);
        for(int i = 1; i<fakeMonths.size(); i++){
            months.add(fakeMonths.get(i));
        }
        //remove the first line of data about months
        records.remove(0);
        //get map: String fruitNames & list prices
        List<String> fakePrices;
        for (int j = 0; j < records.size(); j++) {
            fakePrices = new CopyOnWriteArrayList<>();
            for (int i = 1; i < records.get(j).size(); i++) {
                fakePrices.add(records.get(j).get(i));
            }
            myFruitList.put(records.get(j).get(0), fakePrices);
        }
    }
}
